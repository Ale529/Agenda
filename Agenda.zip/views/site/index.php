<?php

/** @var yii\web\View $this */

use yii\helpers\Url;
use yii\helpers\Html;
use kartik\date\DatePicker;
use yii\widgets\ActiveForm;

$this->title = Yii::$app->name;
$options = ['placeholder' => 'Enter birth date ...', 'readonly' => true];
if (!$model->isNewRecord) {
    $options['value'] = date('d-m-Y', strtotime($model->dob));
}

?>
<div class="site-index">

    <!-- Address Form -->
    <div class="container">
        <?php
        $form = ActiveForm::begin([
            'id' => 'address-form',
            'options' => ['class' => 'form-horizontal'],
            'action' => [Url::base()."/add-address"],
            'method' => 'post'
        ]) ?>
        <div class="row">
            <div class="col-sm-6">
                <div class="mb-3">
                    <?= $form->field($model, 'name') ?>
                </div>
                <div class="mb-3">
                    <?= $form->field($model, 'number') ?>
                </div>
                <div class="mb-3">
                    <?= $form->field($model, 'address')->textarea(['rows' => '3']) ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="mb-3">
                    <?= $form->field($model, 'surname'); ?>
                </div>
                <div class="mb-3">
                    <?= $form->field($model, 'dob')->widget(DatePicker::classname(), [
                        'options' => $options,
                        'type' => DatePicker::TYPE_COMPONENT_APPEND,
                        'pluginOptions' => [
                            'format' => 'd-m-yyyy',
                            'autoclose' => true
                        ]
                    ]); ?>
                </div>
                <div class="mb-3">
                    <?= $form->field($model, 'tags')->textarea(['rows' => '3', 'placeholder' => 'Rich;Poor;Super;Awesome etc..']) ?>
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="col-lg-offset-1 col-lg-11">
                <?= Html::submitButton($model->isNewRecord ? 'Add Address' : 'Update', ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
        <?php 
        echo Html::hiddenInput('id', $model->id);
        ActiveForm::end() 
        ?>
    </div>


    <!-- Address Form -->
</div>