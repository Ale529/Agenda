<?php

$this->title = "Popular Tags";
?>

<div class="site-index">
    <h3><?= $this->title; ?></h3>
    <hr>

    <?php
    if (!empty($usedTags)) {
        foreach ($usedTags as $tag => $count) {
    ?>
            <button type="button" class="btn btn-primary position-relative">
                <?= $tag ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?= $count ?>
                    <span class="visually-hidden">unread messages</span>
                </span>
            </button>
            &nbsp;
    <?php
        }
    }
    ?>
</div>