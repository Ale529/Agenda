<?php

/** @var yii\web\View $this */

use yii\helpers\Url;
use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Contact;
use yii\helpers\ArrayHelper;
use app\models\ContactSearch;
use yii\grid\ActionColumn;

$this->title = "Contact List";

$searchModel = new ContactSearch();
$dataProvider = $searchModel->search(Yii::$app->request->get());
?>

<div class="site-index">
    <div class="container">
        <div class="row text-end">
            <div class="col-sm-12">
                <?php
                echo Html::a('Add Address', Url::base()."/add-address", [
                    'class' => 'btn btn-success text-right mb-1',
                    'title' => 'Add Address'
                ]);
                ?>
                <?php
                echo Html::a('Clear Filter', Url::base()."/address-list", [
                    'class' => 'btn btn-danger text-right mb-1',
                    'title' => 'Clear filters'
                ]);
                ?>
            </div>
        </div>
    </div>

    <?php
    $tagsD = ArrayHelper::map(Contact::find()->select(['tags'])->asArray()->all(), 'tags', 'tags');
    $tags = array_column(Contact::find()->select(['tags'])->asArray()->all(), 'tags');
    $mTags = [];
    foreach ($tags as $tag) {
        $mTags = array_merge(explode(';', $tag), $mTags);
    }
    if (!empty($mTags)) {
        $mTags = array_unique($mTags);
        foreach ($mTags as $key => $t) {
            unset($mTags[$key]);
            $mTags[$t] = $t;
        }
    }

    echo GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            'id',
            'name',
            'surname',
            [
                'label' => 'Age (Year)',
                'attribute' => 'age',
                'value' => function($data) {
                    return $data->age;
                }   
            ],
            [
                'attribute' => 'tags',
                'filter' => $mTags,
                'format' => 'html',
                'value' => function ($data) {
                    $tagHtml = '';
                    if (!empty($data->tags)) {
                        foreach (explode(";", $data->tags) as $tag) {
                            $tagHtml .= '<span class="badge rounded-pill text-bg-primary">' . $tag . '</span>&nbsp;';
                        }
                    }
                    return $tagHtml;
                },
            ],
            [
                'class' => ActionColumn::class,
                'header' => 'Actions',
                'template' => '{update} {delete}',
                'buttons' => [
                    'update' => function ($url) {
                        return Html::a(
                            '<i class="fas fa-edit"></i>',
                            $url,
                            [
                                'title' => 'Edit',
                                'data-pjax' => '0',
                            ]
                        ).'&nbsp;&nbsp;';
                    },
                    'delete' => function ($url, $model) {
                        return Html::a('<i class="fas fa-trash"></i>', ['delete', 'id' => $model->id], [
                            'class' => '',
                            'data' => [
                                'confirm' => 'Are you absolutely sure ? You will lose all the information about this contact with this action.',
                                'method' => 'post',
                            ],
                        ]);
                    },
                ],
            ],
        ]
    ]);
    ?>
</div>