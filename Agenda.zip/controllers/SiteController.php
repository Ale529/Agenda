<?php

namespace app\controllers;

use Yii;
use Exception;
use yii\web\Response;
use app\models\Contact;
use yii\web\Controller;
use app\models\LoginForm;
use app\models\ContactForm;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['logout', 'add-address'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                    [
                        'actions' => ['add-address'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('address-list');
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Address List
     */

    public function actionAddressList()
    {
        return $this->render('address-list');
    }

    public function actionUpdate()
    {
        $id = Yii::$app->request->get('id');
        $model = Contact::findOne($id);
        return $this->render('index', ['model' => $model]);
    }

    public function actionDelete()
    {
        $id = Yii::$app->request->get('id');
        $model = Contact::findOne($id);
        if ($model->delete()) {
            Yii::$app->session->setFlash('success', "Address deleted successfully.");
        } else {
            Yii::$app->session->setFlash('error', "Oops! Something went wrong.");
            return $this->render('index', ['model' => $model]);
        }
        return $this->redirect(['site/address-list']);
    }

    /**
     * Add address in Database
     * 
     */
    public function actionAddAddress()
    {

        $model = new Contact();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            // valid data received in $model
            try {
                $message = "Address has been saved successfully!";
                $address = Yii::$app->request->post('Contact');
                if (Yii::$app->request->post('id') > 0) {
                    $model = Contact::findOne(Yii::$app->request->post('id'));
                    $message = "Address has been updated successfully!";
                }

                // populate data in model
                $model->name = $address['name'];
                $model->number = $address['number'];
                $model->address = $address['address'];
                $model->surname = $address['surname'];
                $model->tags = $address['tags'];
                $model->dob = date("Y-m-d", strtotime($address['dob']));
                $model->created_at = date("Y-m-d");
                if ($model->save()) {
                    Yii::$app->session->setFlash('success', $message);
                } else {
                    Yii::$app->session->setFlash('error', "Oops! Something went wrong.");
                    return $this->render('index', ['model' => $model]);
                }
            } catch (Exception $e) {
                Yii::$app->session->setFlash('error', $e->getMessage());
                return $this->render('index', ['model' => $model]);
            }

            return $this->redirect(['site/address-list']);
        } else {
            return $this->render('index', ['model' => $model]);
        }
    }

    public function actionMostUsedTags() {
        $contacts = Contact::find()->asArray()->all();
        $usedTags = [];
        if(!empty($contacts)) {
            $tags = array_column($contacts, 'tags');
            $mTags = [];
            foreach ($tags as $tag) {
                $mTags = array_merge(explode(';', $tag), $mTags);
            }
            /* if (!empty($mTags)) {
                $mTags = array_unique($mTags);
            } */
            $usedTags = array_count_values($mTags);
        }
        return $this->render('most-used-tags', ['usedTags' => $usedTags]);
    }
}
