<?php

namespace app\models;

use Yii;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "contacts".
 *
 * @property int $id
 * @property string $name
 * @property string $surname
 * @property string $number
 * @property string|null $dob
 * @property string|null $address
 * @property string|null $tags
 */
class Contact extends \yii\db\ActiveRecord
{
    public $age;

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'contacts';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'surname', 'number'], 'required'],
            [['dob'], 'required'],
            [['address', 'tags'], 'required'],
            [['name', 'surname', 'number'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'surname' => 'Surname',
            'number' => 'Phone',
            'dob' => 'Birthdate',
            'address' => 'Address',
            'tags' => 'Tags',
        ];
    }
}
