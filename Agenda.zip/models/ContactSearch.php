<?php

namespace app\models;

use Yii;
use yii\db\Query;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use yii\helpers\VarDumper;

class ContactSearch extends Contact
{
    public function rules()
    {
        // only fields in rules() are searchable
        return [
            [['name', 'surname', 'age', 'tags'], 'string'],
        ];
    }

    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * setup search function for filtering and sorting 
     * based on `orderAmount` field
     */
    public function search($params)
    {
        $query = Contact::find()
            ->select([
                '*',
                'age' => Contact::find()
                    ->select(['year(CURDATE())-year(dob) as age'])
                    ->alias('cin')
                    ->where('cin.id = c.id')
            ])
            ->alias('c');
            /* ->orderBy([
                'c.id' => SORT_DESC,
            ]); */
        /* echo '<pre>';
        print_r($query);
        die; */

        /* $query = Contact::find();
        $subQuery = (new Query())->select('year(CURDATE())-year(dob) as age')->from('contacts')->limit(1);
        $query = (new Query())->select(['name', 'surname', 'dob', 'address', 'age' => $subQuery])->from('contacts'); */
        // $query->select(['id', 'count' => $subQuery]);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);

        /**
         * Setup your sorting attributes
         * Note: This is setup before the $this->load($params) 
         * statement below
         */
        $dataProvider->setSort([
            'attributes' => [
                'id',
                'name',
                'surname',
                'age'
            ]
        ]);

        if (!($this->load($params) && $this->validate())) {
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
        ]);
        // VarDumper::dump($query, 10, true);die;

        $query->andFilterWhere(['like', 'c.name', $this->name])
            ->andFilterWhere(['like', 'c.surname', $this->surname])
            ->andFilterWhere(['like', 'c.address', $this->address])
            ->andFilterWhere(['like', 'c.dob', $this->dob])
            ->andFilterWhere(['like', 'c.tags', $this->tags])
            ->andFilterWhere(['like', 'year(CURDATE())-year(c.dob)', $this->age]);

        return $dataProvider;
    }
}
