<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=address_book',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
